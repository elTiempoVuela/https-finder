pref("extensions.debughelper@teesoft.info.description", "chrome://debughelper/locale/description.properties");  
pref("extensions.venkman.enableChromeFilter", false);


