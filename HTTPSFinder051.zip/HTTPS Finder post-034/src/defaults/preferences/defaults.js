pref("extensions.httpsfinder.enable", true);
pref("extensions.httpsfinder.noruleprompt", false);
pref("extensions.httpsfinder.autoforward", false);
pref("extensions.httpsfinder.firstrun", true);
pref("extensions.httpsfinder.whitelistChanged", false);
pref("extensions.httpsfinder.headfirst", true);
pref("extensions.httpsfinder.showrulepreview", true);
pref("extensions.httpsfinder.version", "0.0");
