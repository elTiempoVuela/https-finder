pref("extensions.{appid}.description", "chrome://{appname}/locale/description.properties");  

