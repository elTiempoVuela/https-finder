function httpsfinderLoadWhitelist(doc){
    var theList = document.getElementById('whitelist');
    try{
        var file = Components.classes["@mozilla.org/file/directory_service;1"]
        .getService(Components.interfaces.nsIProperties)
        .get("ProfD", Components.interfaces.nsIFile);
        file.append("httpsfinder.sqlite");
        var storageService = Components.classes["@mozilla.org/storage/service;1"]
        .getService(Components.interfaces.mozIStorageService);
        var mDBConn = storageService.openDatabase(file);

        var statement = mDBConn.createStatement("SELECT rule FROM whitelist");

        statement.executeAsync({
            handleResult: function(aResultSet){
                //Append each rule to the listbox
                for (let row = aResultSet.getNextRow();   row; row = aResultSet.getNextRow()){
                    var row2 = document.createElement('listitem');
                    var cell = document.createElement('listcell');
                    cell.setAttribute('label', row.getResultByName("rule"));
                    row2.appendChild(cell);
                    theList.appendChild(row2);
                }
            },                           
            handleError: function(anError){
                alert("Error loading rules: " + anError.message);
                Application.console.log("httpsfinder database error " + anError.message);
            },
            handleCompletion: function(aReason){
                if (aReason != Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED)
                    Application.console.log("httpsfinder database error " + aReason.message);
            }
        });
    }
    catch(e){
        Application.console.log("httpsfinder loadWhitelist " + e);
    }
    finally{
        statement.reset();
        mDBConn.asyncClose()
    }
 
}

function httpsfinderModifyWhitelistRule(doc){
    //Remove the rule but paste the text of it back in the textbox for modification
    var theList = document.getElementById('whitelist');
    theList.ensureIndexIsVisible(theList.selectedIndex);
    if(!theList.selectedItem.firstChild.getAttribute("label"))
        return;
    document.getElementById('whitelistURL').value = theList.selectedItem.firstChild.getAttribute("label");
    httpsfinderRemoveWhitelistRule(doc);
}

function httpsfinderRemoveWhitelistRule(doc){
    var theList = document.getElementById('whitelist');
    theList.ensureIndexIsVisible(theList.selectedIndex);
    var selectedItem = theList.selectedItem;
    var url = selectedItem.firstChild.getAttribute("label");
    if(!url)
        return;
    try{
        var file = Components.classes["@mozilla.org/file/directory_service;1"]
        .getService(Components.interfaces.nsIProperties)
        .get("ProfD", Components.interfaces.nsIFile);
        file.append("httpsfinder.sqlite");
        var storageService = Components.classes["@mozilla.org/storage/service;1"]
        .getService(Components.interfaces.mozIStorageService);
        var mDBConn = storageService.openDatabase(file);

        var statement = mDBConn.createStatement("DELETE FROM whitelist where rule = (?1)");
        statement.bindStringParameter(0, url);

        statement.executeAsync({
            handleResult: function(aResultSet){},
            handleError: function(anError){
                alert("Error deleting rule: " + anError.message);
                Application.console.log("httpsfinder whitelist rule delete error " + anError.message);
            },
            handleCompletion: function(aReason){
                //Append new rule to list if it was added without error.
                if (aReason == Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED){
                    theList.removeChild(selectedItem);
                    if(theList.getRowCount() == 0){
                        document.getElementById('modifyRule').disabled = true;
                        document.getElementById('removeRule').disabled = true;
                    }
                    //This should be handled using an XPCOM WrappedJSObject to call the reloadWhitelist() in browserOverlay.js, but
                    //I'm having trouble getting it working.  For a workaround we set a boolPref to whitelistChanged = true, then in browserOverlay
                    //We check for that and reload the whitelist before any whitelist comparisons are done.
                    var prefs = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
                    prefs.setBoolPref("extensions.httpsfinder.whitelistChanged",true);
                }
            }
        });
    }
    catch(e){
        Application.console.log("httpsfinder removeFromWhitelist " + e);
    }
    finally{
        statement.reset();
        mDBConn.asyncClose()
    }
}

function httpsfinderAddToWhitelist(doc){
    var url = document.getElementById('whitelistURL').value.toLowerCase();
    if(url.length == 0){
        alert("No rule specified");
        return;
    }
    var theList = document.getElementById('whitelist');
    try{
        var file = Components.classes["@mozilla.org/file/directory_service;1"]
        .getService(Components.interfaces.nsIProperties)
        .get("ProfD", Components.interfaces.nsIFile);
        file.append("httpsfinder.sqlite");
        var storageService = Components.classes["@mozilla.org/storage/service;1"]
        .getService(Components.interfaces.mozIStorageService);
        var mDBConn = storageService.openDatabase(file);

        var statement = mDBConn.createStatement("INSERT INTO whitelist (rule) VALUES (?1)");
        statement.bindStringParameter(0, url);
        statement.executeAsync({
            handleResult: function(aResultSet){},
            handleError: function(anError){
                alert("Error adding rule: " + anError.message);
                Application.console.log("httpsfinder whitelist rule add error " + anError.message);
            },
            handleCompletion: function(aReason){
                //Append new rule to list if it was added without error.
                if (aReason == Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED){
                    var row2 = document.createElement('listitem');
                    var cell = document.createElement('listcell');
                    cell.setAttribute("label", url);
                    row2.appendChild(cell);
                    theList.appendChild(row2);

                    //This should be handled using an XPCOM WrappedJSObject to call the reloadWhitelist() in browserOverlay.js, but
                    //I'm having trouble getting it working.  For a workaround we set a boolPref to whitelistChanged = true, then in browserOverlay
                    //We check for that and reload the whitelist before any whitelist comparisons are done.
                    var prefs = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
                    prefs.setBoolPref("extensions.httpsfinder.whitelistChanged",true);
                    document.getElementById('whitelistURL').value = "";
                }
            }
        });
    }
    catch(e){
        Application.console.log("httpsfinder addToWhitelist " + e);
    }
    finally{
        statement.reset();
        mDBConn.asyncClose()
    }
    
}

function httpsfinderWhitelistSelect(doc){
    document.getElementById('modifyRule').disabled = false;
    document.getElementById('removeRule').disabled = false;
}