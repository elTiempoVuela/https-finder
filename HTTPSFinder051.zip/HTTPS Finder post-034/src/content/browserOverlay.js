/**
 * httpsfinder namespace
 * VERSION 0.51
 */

if ("undefined" == typeof(httpsfinder)) {
    var httpsfinder = {};
};

window.addEventListener("load", function() {
    httpsfinder.browserOverlay.init();
}, false);

httpsfinder.browserOverlay = {
    prefs: null,
    whitelist: [],
    redirectedTab: [[]],
    tempNoAlerts: [],
    stringsBundle: null,
    httpseverywhereInstalled: false,

    init: function(){
        //Register prefs object
        httpsfinder.browserOverlay.prefs = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);

        var appcontent = document.getElementById("appcontent");   // browser
        if(appcontent)
            appcontent.addEventListener("DOMContentLoaded", httpsfinder.browserOverlay.onPageLoad, true);

        httpsfinder.browserOverlay.stringsBundle = document.getElementById("httpsfinderStrings");
        if(httpsfinder.browserOverlay.prefs == null || httpsfinder.browserOverlay.stringsBundle == null){
            Application.console.log("httpsfinder cannot load preferences or strings - init() failed");
            return; 
        }

        try{
            var installedVersion = httpsfinder.browserOverlay.prefs.getCharPref("extensions.httpsfinder.version");
            var firstrun = httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.firstrun");

            //Create whitelist database
            var file = Components.classes["@mozilla.org/file/directory_service;1"]
            .getService(Components.interfaces.nsIProperties)
            .get("ProfD", Components.interfaces.nsIFile);
            file.append("httpsfinder.sqlite");
            var storageService = Components.classes["@mozilla.org/storage/service;1"]
            .getService(Components.interfaces.mozIStorageService);
            var mDBConn = storageService.openDatabase(file); //Creates db on first run. 
            mDBConn.createTable("whitelist", "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, rule STRING NOT NULL UNIQUE");

        }catch(e){
            //NS_ERROR_FAILURE is thrown when we try to recreate a table (Too generic though...)
            //We try to recreate every start in case the user manually deleted the file
            if(e.name != 'NS_ERROR_FAILURE')
                Application.console.log("httpsfinder initialize error " + e);
        }
        finally{
            mDBConn.close();
            var currentVersion = httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.version");
            if (firstrun){
                httpsfinder.browserOverlay.prefs.setBoolPref("extensions.httpsfinder.firstrun",false);
                httpsfinder.browserOverlay.prefs.setCharPref("extensions.httpsfinder.version", currentVersion);
            }
            else if (installedVersion!=currentVersion && !firstrun){
                //(Upgrade code)
                httpsfinder.browserOverlay.prefs.setCharPref("extensions.httpsfinder.version",currentVersion);
                httpsfinder.browserOverlay.importWhitelist();
            }
            else if(!firstrun)
                httpsfinder.browserOverlay.importWhitelist();            
        }

    },

    importWhitelist: function(){       
        //This shouldn't be needed. But for some reason in Linux just setting length=0 doesn't seem to work for reinitializing this.
        for(var i=0; i <  httpsfinder.browserOverlay.whitelist.length; i++)
            httpsfinder.browserOverlay.whitelist[i] = "";
        httpsfinder.browserOverlay.whitelist.length = 0;
        var whitelist = [];
        try{
            var file = Components.classes["@mozilla.org/file/directory_service;1"]
            .getService(Components.interfaces.nsIProperties)
            .get("ProfD", Components.interfaces.nsIFile);
            file.append("httpsfinder.sqlite");
            var storageService = Components.classes["@mozilla.org/storage/service;1"]
            .getService(Components.interfaces.mozIStorageService);
            var mDBConn = storageService.openDatabase(file);
            var statement = mDBConn.createStatement("SELECT rule FROM whitelist");

            statement.executeAsync({
                handleResult: function(aResultSet){
                    for (let row = aResultSet.getNextRow(); row; row = aResultSet.getNextRow()){
                        whitelist.push(row.getResultByName("rule"));
                    }
                    httpsfinder.browserOverlay.whitelist = whitelist;
                },

                handleError: function(anError){
                    Application.console.log("httpsfinder whitelist database error " + anError.message);
                },

                handleCompletion: function(aReason){
                    if (aReason != Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED)
                        Application.console.log("httpsfinder database error " + aReason.message);
                    else
                        httpsfinder.browserOverlay.prefs.setBoolPref("extensions.httpsfinder.whitelistChanged", false)
                }
            });
        }
        catch(e){
            Application.console.log("httpsfinder load whitelist " + e);
        }
        finally{
            statement.reset();
            mDBConn.asyncClose()
        }
    },

    isTopLevelDocument:  function (aDocument){
        if(typeof aDocument == "undefined")
            return false;
        var browsers = gBrowser.browsers;
        for (var i = 0; i < browsers.length; i++)
            if (aDocument == browsers[i].contentDocument)
                return true;
        return false;
    },

    onPageLoad: function(aEvent) {
        //This is a bad way of doing this.  We check the boolPref for whitelistChanged.  If so we update the whitelist. Need to use
        //XPCOM wrappedJSObject to automatically update the session whitelist when a url is added or removed from preferences.js
        if(httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.whitelistChanged"))
            httpsfinder.browserOverlay.importWhitelist();


        //Return if extension is disabled or if the load event was called from a child object within the page.
        if(!httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.enable") ||
            !httpsfinder.browserOverlay.isTopLevelDocument(aEvent.originalTarget))
            return;
        
        var currenthost = "";
        try{
            currenthost =  gBrowser.getBrowserForDocument(aEvent.originalTarget).currentURI.host.toLowerCase();
        }catch(e){
        //Catches null host on non-web pages like about:config, add-ons manager, etc.
        }


        if(httpsfinder.browserOverlay.isWhitelisted(currenthost))
            return;

        //If this is a new tab that has not been redirected yet, proceed with checking for HTTPS.
        if(typeof httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aEvent.originalTarget)] == "undefined"){
            if(httpsfinder.browserOverlay.getCurrentProtocol(aEvent.originalTarget) == "http" )
                httpsfinder.browserOverlay.detectSSL(aEvent.originalTarget);
        }
        //If user was redirected - Redirected array holds at [x][0] a bool for whether or not the tab index has been redirected.
        //[x][1] holds a string hostname for the pre-redirect URL.  This is necessary because some sites like Google redirect to
        //encrypted.google.com when you use HTTPS.  We have to remember the old URL so it can be whitelisted from the alert drop down.
        else if(httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aEvent.originalTarget)][0]){
            if(!httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.noruleprompt"))
                httpsfinder.browserOverlay.alertSSLEnforced(aEvent.originalTarget);
            httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aEvent.originalTarget)][0] = false;            
        }
        //Else, the tab index has been initialized in the array, but the redirect alert has already been done (bool reset to false)
        else{
            if(httpsfinder.browserOverlay.getCurrentProtocol(aEvent.originalTarget) == "http")
                httpsfinder.browserOverlay.detectSSL(aEvent.originalTarget);
        }        
    },


    whitelistDomain: function(){
        var hostname;
        //If auto-forward was enabled, we pull the pre-redirect URL (Some hosts forward do a new subdomain - like https://google.com
        //Forwards to https://encrypted.google.com - if we don't do this the user will click whitelist, and encrypted.google.com is whitelisted.
        if(typeof httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(gBrowser.contentDocument)] != "undefined" &&
            typeof httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(gBrowser.contentDocument)][1] != "undefined" )
            hostname = httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(gBrowser.contentDocument)][1].host.toLowerCase();
        else
            hostname = gBrowser.currentURI.host.toLowerCase();

        //Bug workaround.  If user closes tab in the middle of open tabs, the indexes are shifted.  The only time we can't just use currentURI
        //is when the https:// page forwards to a subdomain.  This is rare.  With the for loop below, this bug can still happen, but only under the following conditions:
        //1) Auto forward enabled. 2)User browsed to a site where HTTPS forwards to a different hostname 3)conditions 1 and 2 are done in a background tab
        //4) Some tab before the above tab is closed, then user switches to the target tab and clicks "Add to whitelist".  This is unlikely enough that I'm leaving
        //it in for now.  Will look for a better way to do this than the redirectedTab array.
        for(var i=0; i<httpsfinder.browserOverlay.redirectedTab.length; i++){
            if(typeof httpsfinder.browserOverlay.redirectedTab[i] == "undefined" || typeof httpsfinder.browserOverlay.redirectedTab[i][1] == "undefined")
                hostname = hostname; //do nothing
            else if(httpsfinder.browserOverlay.redirectedTab[i][1].host.toLowerCase() == gBrowser.currentURI.host.toLowerCase())
                hostname = gBrowser.currentURI.host.toLowerCase();
        }
     
        try{
            var file = Components.classes["@mozilla.org/file/directory_service;1"]
            .getService(Components.interfaces.nsIProperties)
            .get("ProfD", Components.interfaces.nsIFile);
            file.append("httpsfinder.sqlite");
            var storageService = Components.classes["@mozilla.org/storage/service;1"]
            .getService(Components.interfaces.mozIStorageService);
            var mDBConn = storageService.openDatabase(file);

            var statement = mDBConn.createStatement("INSERT INTO whitelist (rule) VALUES (?1)");
            statement.bindStringParameter(0, hostname);
            statement.executeAsync({
                handleResult: function(aResultSet){},

                handleError: function(anError){
                    alert("Error adding rule: " + anError.message);
                    Application.console.log("httpsfinder whitelist rule add error " + anError.message);
                },
                handleCompletion: function(aReason){
                    if (aReason == Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED){
                        httpsfinder.browserOverlay.whitelist.push(hostname);
                        httpsfinder.browserOverlay.popupNotify(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.ruleAddedTitle"),
                            httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.whitelistAdded"));
                    }
                }
            });
        }
        catch(e){
            Application.console.log("httpsfinder addToWhitelist " + e);
        }
        finally{
            statement.reset();
            mDBConn.asyncClose()
        }
    },

    alertSSLEnforced: function(aDocument){
        if(!httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.noruleprompt")){
            //Check temp whitelist (for rules written this session - it is empited on restart)
            for(var i=0; i < httpsfinder.browserOverlay.tempNoAlerts.length; i++){
                if(httpsfinder.browserOverlay.tempNoAlerts[i] ==
                    gBrowser.getBrowserForDocument(aDocument).currentURI.host.toLowerCase())
                    return; //If it's in the temp whitelist, we don't make another alert, we just forward to https.                
            }
            var nb = gBrowser.getNotificationBox(gBrowser.getBrowserForDocument(aDocument));          
            var saveRuleButtons = [{
                label: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.whitelist"),
                accessKey: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.whitelistKey"),
                popup: null,
                callback: httpsfinder.browserOverlay.whitelistDomain
            },{
                label: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.noThanks"),
                accessKey: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.noThanksKey"),
                popup: null,
                callback: httpsfinder.browserOverlay.closeNotificationAuto
            },{
                label: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.rememberSetting"),
                accessKey: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.rememberSettingKey"),
                popup: null,
                callback: httpsfinder.browserOverlay.writeRule
            }];
            //Alert text changes depending on whether or not user was auto-forwarded to HTTPS.
            if(httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.autoforward"))
                nb.appendNotification(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.autoForwardRulePrompt"),
                    'popup-blocked', 'chrome://httpsfinder/skin/httpsAvailable.png',
                    nb.PRIORITY_INFO_LOW, saveRuleButtons);
            else
                nb.appendNotification(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.saveRulePrompt"),
                    'popup-blocked', 'chrome://httpsfinder/skin/httpsAvailable.png',
                    nb.PRIORITY_INFO_LOW, saveRuleButtons);
        }
    },

    detectSSL: function(aDocument){    
        var tempNoAlerts = false;
        //Check temp whitelist (for rules written this session - it is empited on restart)
        for(var i=0; i < httpsfinder.browserOverlay.tempNoAlerts.length; i++){
            if(httpsfinder.browserOverlay.tempNoAlerts[i] ==
                gBrowser.getBrowserForDocument(aDocument).currentURI.host.toLowerCase())
                tempNoAlerts = true; //If it's in the temp whitelist, we don't make another alert, we just forward to https.
        }
        var nb = gBrowser.getNotificationBox(gBrowser.getBrowserForDocument(aDocument));
        var requestURL = "https://" + httpsfinder.browserOverlay.getFullURL(aDocument);
        var sslFoundButtons = [{
            label: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.whitelist"),
            accessKey: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.whitelistKey"),
            popup: null,
            callback: httpsfinder.browserOverlay.whitelistDomain
        },{
            label: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.noRedirect"),
            accessKey: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.noRedirectKey"),
            popup: null,
            callback: httpsfinder.browserOverlay.closeNotification
        },{
            label: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.yesRedirect"),
            accessKey: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.yesRedirectKey"),
            popup: null,
            callback: httpsfinder.browserOverlay.redirect
        }];
        
        //If user preference specifies GET detection only
        if(!httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.headfirst")){
            var getReq = new XMLHttpRequest();
            getReq.mozBackgroundRequest = true;
            getReq.open('GET', requestURL, true);
            getReq.onreadystatechange = function (aEvt) {
                if (getReq.readyState == 4) {
                    if(getReq.status == 200 && httpsfinder.browserOverlay.testCertificate(getReq.channel)){
                        //Redirect automatically if preference is set
                        if(httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.autoforward")){
                            gBrowser.getBrowserForDocument(aDocument).loadURI(requestURL);
                            //Set array for tab index to TRUE (meaning this tab was redirected), and store the pre-redirect URI.
                            httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)] = new Array();
                            httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)][0] = true;
                            httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)][1] = gBrowser.getBrowserForDocument(aDocument).currentURI;
                        }
                        else if (!tempNoAlerts)
                            nb.appendNotification(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.httpsFoundPrompt"),
                                'popup-blocked','chrome://httpsfinder/skin/httpsAvailable.png',
                                nb.PRIORITY_INFO_LOW, sslFoundButtons);
                    }
                }
            };
            getReq.send(null);
        }
        //Otherwise, try HEAD and fall back to GET if necessary.
        else{
            var headReq = new XMLHttpRequest();
            headReq.mozBackgroundRequest = true;
            headReq.open('HEAD', requestURL, true);
            headReq.onreadystatechange = function (aEvt) {
                if (headReq.readyState == 4) {
                    if(headReq.status == 200 && httpsfinder.browserOverlay.testCertificate(headReq.channel)){
                        //Redirect automatically if preference is set
                        if(httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.autoforward")){
                            gBrowser.getBrowserForDocument(aDocument).loadURI(requestURL);
                            //Set array for tab index to TRUE (meaning this tab was redirected), and store the pre-redirect URI.
                            httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)] = new Array();
                            httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)][0] = true;
                            httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)][1] = gBrowser.getBrowserForDocument(aDocument).currentURI;
                        }
                        else if (!tempNoAlerts)
                            nb.appendNotification(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.httpsFoundPrompt"),
                                'popup-blocked','chrome://httpsfinder/skin/httpsAvailable.png',
                                nb.PRIORITY_INFO_LOW, sslFoundButtons);
                    }
                    else if(headReq.status == 405 || headReq.status == 403){
                        Application.console.log("httpsfinder detection falling back to GET for " +
                            requestURL);
                        var getReq = new XMLHttpRequest();
                        getReq.mozBackgroundRequest = true;
                        getReq.open('GET', requestURL, true);
                        getReq.onreadystatechange = function (aEvt) {
                            if (getReq.readyState == 4)
                                if(getReq.status == 200 && httpsfinder.browserOverlay.testCertificate(getReq.channel)){
                                    if(httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.autoforward")){
                                        gBrowser.getBrowserForDocument(aDocument).loadURI(requestURL);
                                        httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)] = new Array();
                                        httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)][0] = true;
                                        httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)][1] = gBrowser.getBrowserForDocument(aDocument).currentURI;
                                    }
                                    else if (!tempNoAlerts)
                                        nb.appendNotification(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.httpsFoundPrompt"),
                                            'popup-blocked','chrome://httpsfinder/skin/httpsAvailable.png',
                                            nb.PRIORITY_INFO_LOW, sslFoundButtons);
                                }
                        };
                        getReq.send(null);
                    }
                }
            };
            headReq.send(null);    
        }
    },

    isWhitelisted: function(host){
        //Check stored whitelist
        for(var i=0; i < httpsfinder.browserOverlay.whitelist.length; i++){
            var whitelistItem = httpsfinder.browserOverlay.whitelist[i];
            if(whitelistItem == host){
                return true;
            }
            //If rule starts with *., check the end of the hostname (i.e. for *.google.com, check for host ending in .google.com
            else if(whitelistItem.substr(0,2) == "*."){
                //Delete * from rule, compare to last "rule length" chars of the hostname
                if(whitelistItem.replace("*","") == host.substr(host.length - whitelistItem.length + 1,host.length)){
                    return true;
                }
            }
        }
        return false;
    },

    writeRule: function(){

        //Check for https everywhere if it's set to false (once per session since an uninstall will require restart)
        if(!httpsfinder.browserOverlay.httpseverywhereInstalled)
            httpsfinder.browserOverlay.httpsEverywhereInstalled(gBrowser.contentDocument);

        var eTLDService = Components.classes["@mozilla.org/network/effective-tld-service;1"]
        .getService(Components.interfaces.nsIEffectiveTLDService);
        try{
            var topLevel = "." + eTLDService.getPublicSuffix(httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(gBrowser.contentDocument)][1]);
            var hostname = httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(gBrowser.contentDocument)][1].host.toLowerCase();
        }
        catch(e){
            hostname = gBrowser.currentURI.host.toLowerCase();
            topLevel =  "." + eTLDService.getPublicSuffixFromHost(hostname);
        }
        var title = "";

        for(var i=0; i<httpsfinder.browserOverlay.redirectedTab.length; i++){
            if(typeof httpsfinder.browserOverlay.redirectedTab[i] == "undefined" || typeof httpsfinder.browserOverlay.redirectedTab[i][1] == "undefined")
                hostname = hostname; //do nothing
            else if(httpsfinder.browserOverlay.redirectedTab[i][1].host.toLowerCase() == gBrowser.currentURI.host.toLowerCase())
                hostname = gBrowser.currentURI.host.toLowerCase();
            topLevel =  "." + eTLDService.getPublicSuffixFromHost(hostname);
        }

        var tldLength = topLevel.length - 1;

        //Parse URL for domain name (Formatted for rule name (presentation)
        if(hostname.indexOf("www.") != -1)
            title = hostname.slice(hostname.indexOf(".",0) + 1,hostname.lastIndexOf(".",0) - tldLength);
        else
            title = hostname.slice(0, hostname.lastIndexOf(".", 0) - tldLength);
        title = title.charAt(0).toUpperCase() + title.slice(1); //Capitalize for presentation purposes

        var rule;
        //Special case-
        if(hostname == "localhost"){
            title = "Localhost";
            rule = "<ruleset name=\""+ title + "\">" + "\n"
            "<target host=\"" + hostname + "\" />" +
            "<rule from=\"^http://(www\\.)?" + title.toLowerCase() +
            "\\" +"/\"" +" to=\"https://" + title.toLowerCase() +
            "/\"/>" + "\n" + "</ruleset>";
        }
        //This is most cases.  The above only catches localhost since there is no sub/top level domain
        else{
            rule = "<ruleset name=\""+ title + "\">" + "\n"
            + "\t" + "<target host=\"" + hostname + "\" />" + "\n";

            //Check hostname for "www.".
            //One will be "domain.com" and the other will be "www.domain.com"
            var targetHost2 = "";
            if(hostname.indexOf("www.") != -1){
                targetHost2 = hostname.slice(hostname.indexOf(".",0) + 1, hostname.length);
                rule = rule + "\t" + "<target host=\"" + targetHost2 +"\" />" + "\n" +
                "\t" + "<rule from=\"^http://(www\\.)?" + title.toLowerCase() +
                "\\" + topLevel +"/\"" +" to=\"https://www." + title.toLowerCase() +
                topLevel + "/\"/>" + "\n" + "</ruleset>";
            }
            else{
                domains = hostname.split(".");
                if(domains.length == 2){
                    targetHost2 = "www." + hostname;
                    rule = rule + "\t" + "<target host=\"" + targetHost2 +"\" />" +
                    "\n" + "\t" + "<rule from=\"^http://(www\\.)?" + title.toLowerCase() +
                    "\\" + topLevel +"/\"" +" to=\"https://" + title.toLowerCase() +
                    topLevel + "/\"/>" + "\n" + "</ruleset>";
                }
                //If hostname includes non-www subdomain, we don't include www in our rule. (it would direct to the wrong domain).
                else
                    rule = rule + "\t" + "<rule from=\"^http://(www\\.)?" +
                    title.toLowerCase() + "\\" + topLevel +"/\"" +" to=\"https://"
                    + title.toLowerCase() + topLevel + "/\"/>" + "\n" + "</ruleset>";
            }
        }

        rule = rule + "\n" + "<!-- Rule generated by HTTPS Finder " +
        httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.version") +
        " -->"

        if(httpsfinder.browserOverlay.prefs.getBoolPref("extensions.httpsfinder.showrulepreview")){
            var params = {
                inn:{
                    rule:rule
                },
                out:null
            };
            window.openDialog("chrome://httpsfinder/content/rulePreview.xul", "",
                "chrome, dialog, modal,centerscreen, resizable=yes", params).focus();
            if (!params.out)
                return; //user canceled rule
            else
                rule = params.out.rule; //reassign rule value from the textbox
        }
        //Asynchronous for FF3.6+
        //        //Write rule here
        //        var ostream = Components.classes["@mozilla.org/network/file-output-stream;1"].
        //        createInstance(Components.interfaces.nsIFileOutputStream);
        //        var file = Components.classes["@mozilla.org/file/directory_service;1"].
        //        getService(Components.interfaces.nsIProperties).
        //        get("ProfD", Components.interfaces.nsIFile);
        //        file.append("HTTPSEverywhereUserRules")
        //        file.append(title + ".xml");
        //        try{
        //            file.create(Components.interfaces.nsIFile.NORMAL_FILE_TYPE, 0666);
        //        }
        //        catch(e){
        //            if(e.name == 'NS_ERROR_FILE_ALREADY_EXISTS')
        //                file.remove(false);
        //        }
        //        ostream.init(file, 0x02 | 0x08 | 0x20, 0666, ostream.DEFER_OPEN);
        //        var converter = Components.classes["@mozilla.org/intl/scriptableunicodeconverter"].
        //        createInstance(Components.interfaces.nsIScriptableUnicodeConverter);
        //        converter.charset = "UTF-8";
        //        var istream = converter.convertToInputStream(rule);
        //        Components.utils.import("resource://gre/modules/NetUtil.jsm");
        //        NetUtil.asyncCopy(istream, ostream);

        //Compatibality for FF3.5
        //Write rule here
        var foStream = Components.classes["@mozilla.org/network/file-output-stream;1"].
        createInstance(Components.interfaces.nsIFileOutputStream);

        var file = Components.classes["@mozilla.org/file/directory_service;1"].
        getService(Components.interfaces.nsIProperties).
        get("ProfD", Components.interfaces.nsIFile);
        file.append("HTTPSEverywhereUserRules")
        file.append(title + ".xml");
        try{
            file.create(Components.interfaces.nsIFile.NORMAL_FILE_TYPE, 0666);
        }
        catch(e){
            if(e.name == 'NS_ERROR_FILE_ALREADY_EXISTS')
                file.remove(false);
        }
        foStream.init(file, 0x02 | 0x08 | 0x20, 0666, 0);
        var converter = Components.classes["@mozilla.org/intl/converter-output-stream;1"].
        createInstance(Components.interfaces.nsIConverterOutputStream);
        converter.init(foStream, "UTF-8", 0, 0);
        converter.writeString(rule);
        converter.close();

        httpsfinder.browserOverlay.tempNoAlerts.push(gBrowser.currentURI.host.toLowerCase());

        //Check if HTTPSEverywhere is installed.  If not, prompt user.
        //We still save the rule, it will be enforced after HTTPS Everywhere is installed.
        if(httpsfinder.browserOverlay.httpseverywhereInstalled){
            var nb = gBrowser.getNotificationBox();
            var restartButtons = [{
                label: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.restartYes"),
                accessKey: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.restartYesKey"),
                popup: null,
                callback: httpsfinder.browserOverlay.restartNow
            }];
            nb.appendNotification(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.restartPrompt"),
                'popup-blocked','chrome://httpsfinder/skin/httpsAvailable.png',
                nb.PRIORITY_INFO_LOW, restartButtons);
        }
    },

    restartNow: function(){
        Application.restart();
    },

    httpsEverywhereInstalled: function(aDocument){    
        var installButtons = [{
            label: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.getHttpsEverywhere"),
            accessKey: httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.getHttpsEverywhereKey"),
            popup: null,
            callback: httpsfinder.browserOverlay.getHttpsEverywhere
        }];
        var nb = gBrowser.getNotificationBox(gBrowser.getBrowserForDocument(aDocument));  
        
        //Firefox 4+ uses AddonManager, below version 4.0 uses extensions.has - check version and use appropriate method
        if(Application.version.charAt(0) >= 4){
            Components.utils.import("resource://gre/modules/AddonManager.jsm");
            AddonManager.getAddonByID("https-everywhere@eff.org", function(addon) {
                //Addon is null if not installed
                if(addon == null)
                    nb.appendNotification(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.NoHttpsEverywhere"),
                        'popup-blocked','chrome://httpsfinder/skin/httpsAvailable.png',
                        nb.PRIORITY_INFO_LOW, installButtons);                
                else if(addon != null)
                    httpsfinder.browserOverlay.httpseverywhereInstalled = true;
            });
        }
        //Firefox versions below 4.0
        else{
            if(!Application.extensions.has("https-everywhere@eff.org"))
                nb.appendNotification(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.NoHttpsEverywhere"),
                    'popup-blocked','chrome://httpsfinder/skin/httpsAvailable.png',
                    nb.PRIORITY_INFO_LOW, installButtons);
            else
                httpsfinder.browserOverlay.httpseverywhereInstalled = true;
        }
    },

    getHttpsEverywhere: function(){
        gBrowser.selectedTab = gBrowser.addTab("http://www.eff.org/https-everywhere/");
    },

    getCurrentProtocol: function(aDocument) {
        var currentWindow = Components.classes["@mozilla.org/appshell/window-mediator;1"]
        .getService(Components.interfaces.nsIWindowMediator).getMostRecentWindow
        ("navigator:browser");
        return gBrowser.getBrowserForDocument(aDocument).currentURI.scheme;
    },

    getFullURL: function(aDocument) {
        var currURL = gBrowser.getBrowserForDocument(aDocument).currentURI.prePath +
        gBrowser.getBrowserForDocument(aDocument).currentURI.path;
        return currURL.toString().substring((currURL.toString().indexOf("://", 0) + 3));
    },

    closeNotification: function() {
        //User clicked No to stay on HTTP.  Add to temporary whitelist
        httpsfinder.browserOverlay.whitelist.push(gBrowser.currentURI.host.toLowerCase());
        httpsfinder.browserOverlay.popupNotify(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.tempWhitelistedTitle"),
            httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.tempWhitelistedBody"));
    },

    closeNotificationAuto: function() {
        //User clicked Don't save rule from auto-forwarded HTTPS
        httpsfinder.browserOverlay.whitelist.push(gBrowser.currentURI.host.toLowerCase());
        httpsfinder.browserOverlay.popupNotify(httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.tempWhitelistedTitle"),
            httpsfinder.browserOverlay.stringsBundle.getString("httpsfinder.main.tempWhitelistedBody"));
    },

    //Redirect user to secure page (after they click to redirect)
    redirect: function() {
        var aDocument = gBrowser.contentDocument;
        httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)] = new Array();
        httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)][0] = true;

        //Build and save new URI based off pre-redirect URL. Used by post-redirect "Add to whitelist" button.
        var uri = gBrowser.getBrowserForDocument(aDocument).currentURI.asciiSpec
        uri = "https://" + uri.substring((uri.toString().indexOf("://", 0) + 3));
        var ioService = Components.classes["@mozilla.org/network/io-service;1"]
        .getService(Components.interfaces.nsIIOService);
        httpsfinder.browserOverlay.redirectedTab[gBrowser.getBrowserIndexForDocument(aDocument)][1] = ioService.newURI(uri, null, null);
        window.content.wrappedJSObject.location = uri;
    },

    //Generic notifier method
    popupNotify: function(title,body){
        try{
            var alertsService = Components.classes["@mozilla.org/alerts-service;1"]
            .getService(Components.interfaces.nsIAlertsService);
            alertsService.showAlertNotification("chrome://httpsfinder/skin/httpRedirect.png",
                title, body, false, "", null);
        }
        catch(e){
        //Do nothing
        }
    },

    //Certificate testing done before alerting user of https presence
    testCertificate: function(channel) {
        var secure = false;
        try {
            const Ci = Components.interfaces;

            //Do we have a valid channel argument?
            if (! channel instanceof  Ci.nsIChannel)
                return false;

            var secInfo = channel.securityInfo;

            if (secInfo instanceof Ci.nsITransportSecurityInfo) {
                secInfo.QueryInterface(Ci.nsITransportSecurityInfo);
                // Check security state flags
                if ((secInfo.securityState & Ci.nsIWebProgressListener.STATE_IS_SECURE) == Ci.nsIWebProgressListener.STATE_IS_SECURE)
                    secure = true;
            }

            //Check SSL certificate details
            if (secInfo instanceof Ci.nsISSLStatusProvider) {
                var cert = secInfo.QueryInterface(Ci.nsISSLStatusProvider).
                SSLStatus.QueryInterface(Ci.nsISSLStatus).serverCert;

                var verificationResult = cert.verifyForUsage(Ci.nsIX509Cert.CERT_USAGE_SSLServer);

                switch (verificationResult) {
                    case Ci.nsIX509Cert.VERIFIED_OK:
                        secure = true;
                        break;
                    case Ci.nsIX509Cert.NOT_VERIFIED_UNKNOWN:
                        secure = false;
                        break;
                    case Ci.nsIX509Cert.CERT_REVOKED:
                        secure = false;
                        break;
                    case Ci.nsIX509Cert.CERT_EXPIRED:
                        secure = false;
                        break;
                    case Ci.nsIX509Cert.CERT_NOT_TRUSTED:
                        secure = false;
                        break;
                    case Ci.nsIX509Cert.ISSUER_NOT_TRUSTED:
                        secure = false;
                        break;
                    case Ci.nsIX509Cert.ISSUER_UNKNOWN:
                        secure = false;
                        break;
                    case Ci.nsIX509Cert.INVALID_CA:
                        secure = false;
                        break;
                    case Ci.nsIX509Cert.USAGE_NOT_ALLOWED:
                        secure = false;
                        break;
                    default:
                        secure = false;
                        break;
                }
            }
        } catch(err){
            secure = false;
            Application.console.log("httpsfinder testCertificate error: " + err.toString());
        }
        return secure;
    }
};
        /*kj*/
